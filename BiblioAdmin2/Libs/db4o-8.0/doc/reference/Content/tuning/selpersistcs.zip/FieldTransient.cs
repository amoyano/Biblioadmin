/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
using System;

namespace com.db4odoc.f1.selpersist
{
	[AttributeUsage(AttributeTargets.Field)]
	public class FieldTransient: Attribute
	{
	}
}
