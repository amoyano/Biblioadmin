/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
namespace Db4objects.Db4odoc.SelectivePersistence
{
	public class Test
	{
        [Db4objects.Db4o.Transient]
		string _transientField;
		string _persistentField;

		public Test(string transientField, string persistentField)
		{
			_transientField = transientField;
			_persistentField = persistentField;
		}

		public override string ToString() 
		{
			return "Test: persistent: " + _persistentField + ", transient: " + _transientField ;
		}
	}
}
