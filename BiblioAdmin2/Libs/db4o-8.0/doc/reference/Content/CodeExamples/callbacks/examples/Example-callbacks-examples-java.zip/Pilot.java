package com.db4odoc.callbacks.examples;


class Pilot {
    private String name;

    Pilot(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
