package com.db4odoc.configuration.alias.old.location;


public class Pilot {
    private String name = "Joe";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
