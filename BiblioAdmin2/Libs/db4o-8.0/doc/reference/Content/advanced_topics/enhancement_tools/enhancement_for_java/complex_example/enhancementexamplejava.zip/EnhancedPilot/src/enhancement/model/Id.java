/* Copyright (C) 2007  db4objects Inc.  http://www.db4o.com */
package enhancement.model;

public class Id {
	String _id;
	
	public Id(String id){
		_id = id;
	}
	
	public String toString(){
		return _id;
	}
}
