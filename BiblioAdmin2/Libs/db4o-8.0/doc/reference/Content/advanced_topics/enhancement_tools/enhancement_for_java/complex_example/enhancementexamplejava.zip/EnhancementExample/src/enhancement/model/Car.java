package enhancement.model;

import tacustom.*;

@Db4oPersistent
public class Car {

	private String _model = null;
	Pilot _pilot;

	public Car(String content, Pilot pilot) {
		_model = content;
		_pilot = pilot;
	}
	
	public String content() {
		return _model;
	}

	public void content(String content) {
		_model = content;
	}
	
	@Override
	public String toString() {
		return _model + "/" + _pilot;
	}

	public String getModel() {
		return _model;
	}

	public Pilot getPilot() {
		return _pilot;
	}
}
