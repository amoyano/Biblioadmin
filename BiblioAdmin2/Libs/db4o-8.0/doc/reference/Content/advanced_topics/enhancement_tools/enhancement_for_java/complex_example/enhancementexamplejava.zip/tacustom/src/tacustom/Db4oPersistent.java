package tacustom;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
public @interface Db4oPersistent {
}
