/* Copyright (C) 2007  db4objects Inc.  http://www.db4o.com */
package enhancement.model;

public class Pilot {
	String _name;
	Id _id;
	
	public Pilot(String name, Id id){
		_name = name;
		_id = id;
	}
	
	public String get_name() {
		return _name;
	}
	public void set_name(String _name) {
		this._name = _name;
	}
	public Id get_id() {
		return _id;
	}
	public void set_id(Id _id) {
		this._id = _id;
	}
	
	public String toString(){
		return _name + ": " + _id;
	}
}
